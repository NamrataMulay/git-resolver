module.exports = {
  rootTranslationsPath: 'src/assets/i18n/',
  langs: ['en', 'hi', 'fr'],
  keysManager: {}
};