export class Emp {
  name: string;
  cnumber: number;
  dob: string;
  address: string;
  empID: number;
}
