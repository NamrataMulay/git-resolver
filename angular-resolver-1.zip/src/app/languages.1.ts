export interface Languages {
  name: string;
  code: string;
}
