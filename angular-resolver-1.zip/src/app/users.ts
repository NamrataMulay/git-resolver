export interface Customer {
  id: number;
  name: string;
  email: string;
  gender: string;
  created_at: number ;
  updated_at: number;
}

